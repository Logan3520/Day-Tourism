# City Explorers

A modern web application built with React frontend and Python Flask backend to explore tourist attractions across multiple cities including Pune, Mumbai, Delhi, and Kolkata.

## Architecture

- **Frontend**: React.js with modern UI components and responsive design
- **Backend**: Python Flask API with RESTful endpoints
- **Data**: 16 attractions (8 in Pune + 8 nearby destinations)

## Features

- 🏛️ Browse Pune city attractions
- 🏔️ Discover nearby getaways (hill stations, forts, nature spots)
- 🎯 Filter attractions by category (Historical, Religious, Adventure, Nature, etc.)
- 📱 Responsive design for all devices
- 🔍 Detailed attraction information with images
- 🌐 API-driven architecture

## Quick Start

### Backend Setup (Required)

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the Flask API server:**
   ```bash
   python app.py
   ```
   
   The API will be available at `http://127.0.0.1:5000`

### Frontend Setup

1. **Navigate to project root:**
   ```bash
   cd ..  # if you're in backend folder
   ```

2. **Install React dependencies:**
   ```bash
   npm install
   ```

3. **Start the React development server:**
   ```bash
   npm start
   ```
   
   The app will be available at `http://localhost:3000`

## API Endpoints

- `GET /` - API status
- `GET /api/pune-attractions` - Get all Pune attractions
- `GET /api/nearby-attractions` - Get all nearby attractions  
- `GET /api/attraction/<id>` - Get specific attraction by ID
- `GET /api/attractions/category/<category>` - Get attractions by category

## Categories

- **historical** - Forts, palaces, heritage sites
- **religious** - Temples, spiritual centers
- **adventure** - Trekking, outdoor activities
- **nature** - Gardens, parks, natural beauty
- **cultural** - Museums, art centers
- **spiritual** - Meditation centers, ashrams
- **hillstation** - Hill stations, scenic spots
- **modern** - Contemporary attractions

## Project Structure

```
city-explorers/
├── backend/                 # Python Flask API
│   ├── app.py              # Main Flask application
│   ├── requirements.txt    # Python dependencies
│   └── README.md          # Backend documentation
├── src/                    # React frontend
│   ├── components/         # Reusable UI components
│   ├── pages/             # Page components
│   ├── services/          # API service layer
│   └── assets/           # Images and static files
├── public/               # Public assets
└── package.json         # Node.js dependencies
```

## Development Notes

- The React app fetches data from the Flask API instead of local data files
- CORS is enabled on the backend for cross-origin requests
- Loading states and error handling are implemented throughout the app
- Responsive design works on mobile, tablet, and desktop

## Original Data

The attraction data includes:
- **Pune Attractions**: Shaniwar Wada, Aga Khan Palace, Sinhagad Fort, Dagdusheth Temple, Osho Ashram, Saras Baug, Kelkar Museum, Mohammad Shah's Tomb
- **Nearby Attractions**: Lonavala, Khandala, Mulshi Dam, Rajgad Fort, Bhimashankar, Mahabaleshwar, Tamhini Ghat, Lavasa

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test both frontend and backend
5. Submit a pull request

## License

This project is open source and available under the MIT License.
